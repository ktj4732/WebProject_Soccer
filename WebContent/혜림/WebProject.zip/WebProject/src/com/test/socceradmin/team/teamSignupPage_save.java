package com.test.socceradmin.team;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.test.soccer.controller.action.Action;

public class teamSignupPage_save implements Action {
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		int uploadFileSizeLimit = 5 * 1024 * 1024;
		String encType = "UTF-8";

		String uploadFilePath = (String) request.getAttribute("uploadFilePath");
		
		System.out.println("�������� ���� ���丮 :" + uploadFilePath);
		
		try {
			
			MultipartRequest multi = new MultipartRequest(request, // request ��ü
					uploadFilePath, // �������� ���� ���丮
					uploadFileSizeLimit, // �ִ� ���ε� ���� ũ��
					encType, // ���ڵ� ���

			new DefaultFileRenamePolicy());
			
			System.out.println(multi.getParameter("teamName"));
			System.out.println(multi.getParameter("teamMember"));
			System.out.println(multi.getParameter("teamMaster"));
			System.out.println(multi.getParameter("tel"));
			System.out.println(multi.getParameter("tel2"));
			System.out.println(multi.getParameter("tel3"));
			System.out.println(multi.getParameter("homeGround"));
			System.out.println(multi.getParameter("teamCity"));
			System.out.println(multi.getParameter("teamIntroduce"));
			
			Enumeration file = multi.getFileNames();
			String str = (String)file.nextElement();
			
			String filename = multi.getFilesystemName(str);
			System.out.println(filename);
			

		} catch (Exception e) {
			System.out.print("���� �߻� : " + e);
		} // catch

		
		
		String url = "views/teamList.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
		
	}
}