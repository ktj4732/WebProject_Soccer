package com.test.soccer.dao;

public class tblleagueDAO {

}
