package com.test.soccer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.test.soccer.controller.DBUtil;
import com.test.soccer.dto.tblcoachDTO;

public class tblcoachDAO {
	
	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	private ResultSet rs;
	
	public tblcoachDAO() {
		DBUtil util = new DBUtil();
		conn = util.open();
	}
	
	public void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	public tblcoachDTO get() {
		
		try {

			String sql = "select * from tblcoachDTO";
			
			stat = conn.createStatement();
			rs = stat.executeQuery(sql);
			
			if (rs.next()) {
				tblcoachDTO dto = new tblcoachDTO();
				dto.setSeq(rs.getString("seq"));
				dto.setTeam_seq(rs.getString("team_seq"));
				dto.setMember_seq(rs.getString("member_seq"));
				dto.setState(rs.getString("state"));
				return dto;
			}
			

		} catch (Exception e) {
			System.out.println("HistoryDAO.get()");
			e.printStackTrace();
		}
		
		return null;
	}


}

