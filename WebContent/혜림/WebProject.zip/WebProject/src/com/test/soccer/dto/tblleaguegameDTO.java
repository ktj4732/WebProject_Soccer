package com.test.soccer.dto;

public class tblleaguegameDTO {
	
	private String seq;
	private String gamedate; 
	private String ground_seq;
	private String hometeam_seq;
	private String awayteam_seq;
	private String league_seq;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getGamedate() {
		return gamedate;
	}
	public void setGamedate(String gamedate) {
		this.gamedate = gamedate;
	}
	public String getGround_seq() {
		return ground_seq;
	}
	public void setGround_seq(String ground_seq) {
		this.ground_seq = ground_seq;
	}
	public String getHometeam_seq() {
		return hometeam_seq;
	}
	public void setHometeam_seq(String hometeam_seq) {
		this.hometeam_seq = hometeam_seq;
	}
	public String getAwayteam_seq() {
		return awayteam_seq;
	}
	public void setAwayteam_seq(String awayteam_seq) {
		this.awayteam_seq = awayteam_seq;
	}
	public String getLeague_seq() {
		return league_seq;
	}
	public void setLeague_seq(String league_seq) {
		this.league_seq = league_seq;
	} 

}
