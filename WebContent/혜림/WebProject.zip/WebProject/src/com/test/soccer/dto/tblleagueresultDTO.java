package com.test.soccer.dto;

public class tblleagueresultDTO {
	
	private String seq;
	private String leaguegame_seq; 
	private String homegoal; 
	private String awaygoal;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getLeaguegame_seq() {
		return leaguegame_seq;
	}
	public void setLeaguegame_seq(String leaguegame_seq) {
		this.leaguegame_seq = leaguegame_seq;
	}
	public String getHomegoal() {
		return homegoal;
	}
	public void setHomegoal(String homegoal) {
		this.homegoal = homegoal;
	}
	public String getAwaygoal() {
		return awaygoal;
	}
	public void setAwaygoal(String awaygoal) {
		this.awaygoal = awaygoal;
	} 

}
