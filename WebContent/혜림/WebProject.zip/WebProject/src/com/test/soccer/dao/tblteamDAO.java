package com.test.soccer.dao;

public class tblteamDAO {

}
