package com.test.soccer.controller;

import com.test.soccer.controller.action.Action;
import com.test.socceradmin.schedule.leaguescheduleRegister_show;
import com.test.socceradmin.schedule.leaguescheduleSearch_show;
import com.test.socceradmin.team.teamList_show;
import com.test.socceradmin.team.teamSignupPage_save;
import com.test.socceradmin.team.teamSignupPage_show;

public class ActionFactory {
	private static ActionFactory instance = new ActionFactory();

	private ActionFactory() {
		super();
	}

	public static ActionFactory getInstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action = null;

		/* �߰��� �κ� */
		if (command.equals("teamList")) {
			action = new teamList_show();
		}else if (command.equals("teamSignupPage")) {
			action = new teamSignupPage_show();
		}else if (command.equals("leaguescheduleRegister")) {
			action = new leaguescheduleRegister_show();
		}else if (command.equals("leaguescheduleSearch")) {
			action = new leaguescheduleSearch_show();
		}else if (command.equals("teamSignupPage_save")) {
			action = new teamSignupPage_save();
		}else if (command.equals("teamList_del")) {
			
		}else if (command.equals("teamSignupPage_update")) {
			
		}
		
	
		return action;
	}
}

