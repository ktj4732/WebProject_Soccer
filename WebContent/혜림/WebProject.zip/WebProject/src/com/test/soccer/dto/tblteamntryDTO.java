package com.test.soccer.dto;

public class tblteamntryDTO {
	
	private String seq; 
	private String team_seq; 
	private String league_seq;
	private String point;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTeam_seq() {
		return team_seq;
	}
	public void setTeam_seq(String team_seq) {
		this.team_seq = team_seq;
	}
	public String getLeague_seq() {
		return league_seq;
	}
	public void setLeague_seq(String league_seq) {
		this.league_seq = league_seq;
	}
	public String getPoint() {
		return point;
	}
	public void setPoint(String point) {
		this.point = point;
	} 
	

}
