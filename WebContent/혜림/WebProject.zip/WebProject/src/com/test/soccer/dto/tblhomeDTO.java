package com.test.soccer.dto;

public class tblhomeDTO {
	
	private String seq;
	private String home;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getHome() {
		return home;
	}
	public void setHome(String home) {
		this.home = home;
	}
	
	

}
