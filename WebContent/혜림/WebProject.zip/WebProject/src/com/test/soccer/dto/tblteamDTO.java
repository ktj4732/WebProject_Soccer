package com.test.soccer.dto;

public class tblteamDTO {
	
	private String seq; 
	private String name; 
	private String logo; 
	private String birth; 
	private String slogan; 
	private String teamground; 
	private String teamground_seq;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getSlogan() {
		return slogan;
	}
	public void setSlogan(String slogan) {
		this.slogan = slogan;
	}
	public String getTeamground() {
		return teamground;
	}
	public void setTeamground(String teamground) {
		this.teamground = teamground;
	}
	public String getTeamground_seq() {
		return teamground_seq;
	}
	public void setTeamground_seq(String teamground_seq) {
		this.teamground_seq = teamground_seq;
	} 
	

}
