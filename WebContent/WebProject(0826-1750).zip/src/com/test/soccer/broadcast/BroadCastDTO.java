package com.test.soccer.broadcast;

public class BroadCastDTO {
	
	private String seq;
	private String time;
	private String broadcastAct_seq;
	private String leagueGame_seq;
	private String playerEntry_seq;
	private String shortCout;
	private String event;
	private String playerName;
	private String team;
	
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getBroadcastAct_seq() {
		return broadcastAct_seq;
	}
	public void setBroadcastAct_seq(String broadcastAct_seq) {
		this.broadcastAct_seq = broadcastAct_seq;
	}
	public String getLeagueGame_seq() {
		return leagueGame_seq;
	}
	public void setLeagueGame_seq(String leagueGame_seq) {
		this.leagueGame_seq = leagueGame_seq;
	}
	public String getPlayerEntry_seq() {
		return playerEntry_seq;
	}
	public void setPlayerEntry_seq(String playerEntry_seq) {
		this.playerEntry_seq = playerEntry_seq;
	}
	public String getShortCout() {
		return shortCout;
	}
	public void setShortCout(String shortCout) {
		this.shortCout = shortCout;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	
	
	
	
	
}
