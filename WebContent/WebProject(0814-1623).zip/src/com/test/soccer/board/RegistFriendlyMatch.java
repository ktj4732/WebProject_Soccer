package com.test.soccer.board;

public class RegistFriendlyMatch {

	
}
