package com.test.soccer.schedule;

public class LeagueResultDTO {

}
